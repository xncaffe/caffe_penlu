prelu函数以alpha=0.25初始化，elu函数以alpha=1来初始化。
taylor初始化的参数alpha/beta设置与激活函数的参数alpha/beta相对应
